# Third-party notices

- Demucs Android engine: https://github.com/jPaauwe/demucs-android — MIT license. The build workflow fetches this project and its Eigen submodule at build time.
- Demucs `htdemucs_6s` weights: published by the Demucs project, MIT license. Downloaded by the app from the pinned Hugging Face revision and checked against the SHA-256 embedded in `SeparationManager.kt`.
- Eigen: MPL-2.0, fetched as a submodule of the Demucs Android engine.
