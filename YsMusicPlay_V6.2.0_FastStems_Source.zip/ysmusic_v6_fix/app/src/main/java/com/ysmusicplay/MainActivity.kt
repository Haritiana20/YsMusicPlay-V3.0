package com.ysmusicplay

import android.Manifest
import android.app.Activity
import android.content.pm.ActivityInfo
import android.content.ComponentName
import android.content.Intent
import android.content.ContentUris
import android.content.pm.PackageManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.AudioManager
import android.view.WindowManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.IntentSenderRequest
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.animation.core.*
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.CircleShape
import androidx.media3.common.PlaybackParameters
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale


data class MediaEntry(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val uri: Uri,
    val folder: String,
    val dateAdded: Long,
    val artwork: Uri? = null,
    val video: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            val controller = runCatching { future.get() }.getOrNull()
            if (controller != null) setContent { YsMusicApp(controller) }
            else setContent { ErrorScreen("Impossible de se connecter au lecteur. Redémarrez l’application.") }
        }, MoreExecutors.directExecutor())
    }
}

@Composable
private fun ErrorScreen(message: String) {
    MaterialTheme(colorScheme = darkColorScheme()) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), contentAlignment = Alignment.Center) {
            Text(message, color = Color.White)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun YsMusicApp(player: MediaController) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var separationStatus by remember { mutableStateOf("") }
    var separationBusy by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf("Audio") }
    var audioSection by remember { mutableStateOf("Hira") }
    var audio by remember { mutableStateOf(emptyList<MediaEntry>()) }
    var videos by remember { mutableStateOf(emptyList<MediaEntry>()) }
    var selectedVideoFolder by remember { mutableStateOf<String?>(null) }
    var current by remember { mutableStateOf<MediaEntry?>(null) }
    var nowPlaying by remember { mutableStateOf(false) }
    var videoScreen by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var sortMode by remember { mutableStateOf("Anarana") }
    var scanInfo by remember { mutableStateOf("En attente de l’autorisation d’accès aux fichiers...") }
    var playing by remember { mutableStateOf(false) }
    var duration by remember { mutableLongStateOf(0L) }
    var position by remember { mutableLongStateOf(0L) }
    var shuffle by remember { mutableStateOf(false) }
    var lyricsText by remember { mutableStateOf("") }
    var eqEnabled by remember { mutableStateOf(false) }
    var bassEnabled by remember { mutableStateOf(false) }
    var equalizer by remember { mutableStateOf<Equalizer?>(null) }
    var bassBoost by remember { mutableStateOf<BassBoost?>(null) }
    var loudnessEnhancer by remember { mutableStateOf<LoudnessEnhancer?>(null) }
    var boosterEnabled by remember { mutableStateOf(false) }
    val prefs = remember { context.getSharedPreferences("ys_music_prefs", android.content.Context.MODE_PRIVATE) }
    var darkTheme by remember { mutableStateOf(prefs.getBoolean("dark_theme", true)) }
    var accentIndex by remember { mutableIntStateOf(prefs.getInt("accent_index", 0).coerceIn(0, 4)) }
    var language by remember { mutableStateOf(prefs.getString("language", "Français") ?: "Français") }
    var backgroundImageUri by remember { mutableStateOf(prefs.getString("background_image_uri", null)) }
    var dataSaver by remember { mutableStateOf(prefs.getBoolean("data_saver", false)) }
    val backgroundPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            backgroundImageUri = uri.toString()
            prefs.edit().putString("background_image_uri", uri.toString()).apply()
        }
    }
    var repeatMode by remember { mutableIntStateOf(prefs.getInt("repeat_mode", 0).coerceIn(0, 2)) }
    var alvinEnabled by remember { mutableStateOf(false) }
    val accentChoices = listOf(Color(0xFFFF8A00), Color(0xFF2196F3), Color(0xFF4CAF50), Color(0xFFE91E63), Color(0xFF9C27B0))
    val chosenAccent = accentChoices[accentIndex]
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()) }
    var showFavorites by remember { mutableStateOf(false) }
    var showEqualizer by remember { mutableStateOf(false) }
    var youtubeSearchUrl by remember { mutableStateOf<String?>(null) }
    var youtubeMode by remember { mutableStateOf(false) }
    var infoEntry by remember { mutableStateOf<MediaEntry?>(null) }
    var selectedPreset by remember { mutableStateOf("Normal") }
    fun favoriteKey(entry: MediaEntry) = "${entry.video}:${entry.id}"
    fun toggleFavorite(entry: MediaEntry) {
        val next = favorites.toMutableSet()
        val key = favoriteKey(entry)
        if (!next.add(key)) next.remove(key)
        favorites = next
        prefs.edit().putStringSet("favorites", next).apply()
    }

    fun scanLibrary() {
        val foundAudio = mutableListOf<MediaEntry>()
        val foundVideo = mutableListOf<MediaEntry>()
        runCatching {
            val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(
                MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.ALBUM_ID
            )
            context.contentResolver.query(collection, projection, null, null,
                "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
                val idI = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val dataI = c.getColumnIndex(MediaStore.Audio.Media.DATA)
                val dateI = c.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED)
                val albumIdI = c.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)
                while (c.moveToNext()) {
                    val id = c.getLong(idI)
                    val path = if (dataI >= 0) c.getString(dataI).orEmpty() else ""
                    val albumId = if (albumIdI >= 0) c.getLong(albumIdI) else -1L
                    val art = if (albumId > 0) Uri.parse("content://media/external/audio/albumart/$albumId") else null
                    foundAudio += MediaEntry(
                        id, c.getString(titleI) ?: if (language == "Français") "Titre inconnu" else "Hira tsy fantatra",
                        c.getString(artistI) ?: if (language == "Français") "Artiste inconnu" else "Mpanakanto tsy fantatra",
                        c.getString(albumI) ?: if (language == "Français") "Album inconnu" else "Rakikira tsy fantatra",
                        c.getLong(durationI),
                        ContentUris.withAppendedId(collection, id),
                        path.substringBeforeLast("/", "Music"),
                        if (dateI >= 0) c.getLong(dateI) else 0L, art
                    )
                }
            }
        }.onFailure { scanInfo = if (language == "Français") "Erreur de lecture audio : ${it.message ?: "erreur"}" else "Tsy nahomby ny famakiana hira: ${it.message ?: "hadisoana"}" }

        runCatching {
            val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE,
                MediaStore.Video.Media.DURATION, MediaStore.Video.Media.DATA, MediaStore.Video.Media.DATE_ADDED)
            context.contentResolver.query(collection, projection, null, null,
                "${MediaStore.Video.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
                val idI = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleI = c.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val durI = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val dataI = c.getColumnIndex(MediaStore.Video.Media.DATA)
                val dateI = c.getColumnIndex(MediaStore.Video.Media.DATE_ADDED)
                while (c.moveToNext()) {
                    val id = c.getLong(idI)
                    val path = if (dataI >= 0) c.getString(dataI).orEmpty() else ""
                    foundVideo += MediaEntry(id, c.getString(titleI) ?: if (language == "Français") "Vidéo" else "Video", "", "",
                        c.getLong(durI), ContentUris.withAppendedId(collection, id),
                        path.substringBeforeLast("/", "Videos").substringAfterLast("/"),
                        if (dateI >= 0) c.getLong(dateI) else 0L, video = true)
                }
            }
        }.onFailure { scanInfo = if (language == "Français") "Erreur de lecture vidéo : ${it.message ?: "erreur"}" else "Tsy nahomby ny famakiana vidéo: ${it.message ?: "hadisoana"}" }

        audio = foundAudio
        videos = foundVideo
        scanInfo = if (language == "Français") "${audio.size} titres et ${videos.size} vidéos trouvés." else "${audio.size} hira sy ${videos.size} vidéo hita."
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants.values.any { it }) scanLibrary()
        else scanInfo = if (language == "Français") "Accès aux fichiers refusé. Vérifiez les autorisations Android." else "Tsy nomena alalana hamaky ny rakitra. Jereo ny Fahazoan-dalana ao amin'ny fikirana Android."
    }

    fun requestLibraryAccess() {
        val permissions = when {
            Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO)
            else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) scanLibrary() else permissionLauncher.launch(missing.toTypedArray())
    }

    fun playEntry(entry: MediaEntry, list: List<MediaEntry>) {
        val ordered = list
        val index = ordered.indexOfFirst { it.id == entry.id && it.video == entry.video }.coerceAtLeast(0)
        val items = ordered.map { e ->
            val metadata = MediaMetadata.Builder()
                .setTitle(e.title).setArtist(e.artist)
                .setAlbumTitle(e.album)
                .apply { e.artwork?.let { setArtworkUri(it) } }
                .build()
            MediaItem.Builder().setUri(e.uri).setMediaMetadata(metadata).build()
        }
        player.setMediaItems(items, index, 0L)
        player.shuffleModeEnabled = shuffle
        player.repeatMode = when (repeatMode) {
            1 -> Player.REPEAT_MODE_ONE
            2 -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }
        player.prepare()
        player.play()
        current = entry
        nowPlaying = !entry.video
        videoScreen = entry.video
    }


    LaunchedEffect(Unit) {
        player.repeatMode = when (repeatMode) {
            1 -> Player.REPEAT_MODE_ONE
            2 -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }
        requestLibraryAccess()
    }
    DisposableEffect(player) {
        val noisyReceiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(context: android.content.Context?, intent: android.content.Intent?) {
                if (intent?.action == android.media.AudioManager.ACTION_AUDIO_BECOMING_NOISY) player.pause()
            }
        }
        val noisyFilter = android.content.IntentFilter(android.media.AudioManager.ACTION_AUDIO_BECOMING_NOISY)
        runCatching { ContextCompat.registerReceiver(context, noisyReceiver, noisyFilter, ContextCompat.RECEIVER_NOT_EXPORTED) }
        val listener = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val title = mediaItem?.mediaMetadata?.title?.toString().orEmpty()
                val artist = mediaItem?.mediaMetadata?.artist?.toString().orEmpty()
                current = (if (videoScreen) videos else audio).firstOrNull { it.title == title && (it.video == videoScreen) }
                    ?: current?.copy(title = title, artist = artist)
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            runCatching { context.unregisterReceiver(noisyReceiver) }
            runCatching { equalizer?.release() }
            runCatching { bassBoost?.release() }
            runCatching { loudnessEnhancer?.release() }
        }
    }
    LaunchedEffect(player) {
        while (true) {
            playing = player.isPlaying
            duration = player.duration.takeIf { it > 0 && it != androidx.media3.common.C.TIME_UNSET } ?: (current?.duration ?: 0L)
            position = player.currentPosition.coerceAtLeast(0L)
            delay(400)
        }
    }

    val filteredAudio = audio.filter {
        val q = search.trim().lowercase(Locale.ROOT)
        (q.isEmpty() || it.title.lowercase(Locale.ROOT).contains(q) ||
            it.artist.lowercase(Locale.ROOT).contains(q) || it.album.lowercase(Locale.ROOT).contains(q) ||
            it.folder.lowercase(Locale.ROOT).contains(q)) &&
            (!showFavorites || favoriteKey(it) in favorites)
    }
    val sortedAudio = when (sortMode) {
        "Daty" -> filteredAudio.sortedByDescending { it.dateAdded }
        "Faharetana" -> filteredAudio.sortedByDescending { it.duration }
        else -> filteredAudio.sortedBy { it.title.lowercase(Locale.ROOT) }
    }
    val filteredVideos = videos.filter { it.title.contains(search, true) || it.folder.contains(search, true) }
    val videoFolders = filteredVideos.groupBy { it.folder.ifBlank { if (language == "Français") "Autres" else "Hafa" } }.toSortedMap(String.CASE_INSENSITIVE_ORDER)
    val selectedFolderVideos = selectedVideoFolder?.let { folder -> filteredVideos.filter { (it.folder.ifBlank { if (language == "Français") "Autres" else "Hafa" }) == folder } }.orEmpty()

    val deleteRequestLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) scanLibrary()
    }

    fun handleMediaMenu(entry: MediaEntry, action: String) {
        when (action) {
            "Lire tout" -> playEntry(entry, if (entry.video) selectedFolderVideos.ifEmpty { videos } else sortedAudio)
            "Ajouter à la file d’attente" -> runCatching { player.addMediaItem(MediaItem.fromUri(entry.uri)) }
            "Ajouter juste après" -> runCatching {
                val item = MediaItem.fromUri(entry.uri)
                player.addMediaItem((player.currentMediaItemIndex + 1).coerceAtMost(player.mediaItemCount), item)
            }
            "Information" -> infoEntry = entry
            "Accéder à l’album" -> { page = "Audio"; audioSection = "Rakikira"; search = entry.album }
            "Accéder à l’artiste" -> { page = "Audio"; audioSection = "Mpanakanto"; search = entry.artist }
            "Ajouter aux favoris" -> toggleFavorite(entry)
            "Partager" -> runCatching {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = if (entry.video) "video/*" else "audio/*"
                    putExtra(Intent.EXTRA_STREAM, entry.uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, "Partager"))
            }
            "Supprimer" -> runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val request = MediaStore.createDeleteRequest(context.contentResolver, listOf(entry.uri))
                    deleteRequestLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
                } else {
                    context.contentResolver.delete(entry.uri, null, null)
                    scanLibrary()
                }
            }
            "Parcourir le parent" -> if (entry.video) {
                page = "Video"
                selectedVideoFolder = entry.folder
            } else {
                page = "Audio"
                audioSection = "Hira"
                showFavorites = false
                search = entry.folder
            }
        }
    }


    BackHandler(enabled = youtubeSearchUrl != null || nowPlaying || videoScreen || selectedVideoFolder != null || showQueue || showLyrics || showAbout || showEqualizer) {
        when {
            youtubeSearchUrl != null -> youtubeSearchUrl = null
            showQueue -> showQueue = false
            showLyrics -> showLyrics = false
            showAbout -> showAbout = false
            showEqualizer -> showEqualizer = false
            videoScreen -> { videoScreen = false }
            nowPlaying -> nowPlaying = false
            selectedVideoFolder != null -> selectedVideoFolder = null
        }
    }

    MaterialTheme(colorScheme = if (darkTheme) darkColorScheme(
        primary = chosenAccent, secondary = chosenAccent,
        background = Color(0xFF101114), surface = Color(0xFF202127),
        onBackground = Color.White, onSurface = Color.White,
        onSurfaceVariant = Color(0xFFD0D0D4)
    ) else lightColorScheme(
        primary = chosenAccent, secondary = chosenAccent,
        background = Color(0xFFF4F5F7), surface = Color.White,
        onBackground = Color(0xFF17181D), onSurface = Color(0xFF17181D),
        onSurfaceVariant = Color(0xFF4B4D52)
    )) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            if (!backgroundImageUri.isNullOrBlank()) {
                AsyncImage(
                    model = Uri.parse(backgroundImageUri),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background.copy(alpha = 0.38f)))
            }
            Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                if (!nowPlaying && !videoScreen) {
                    Column {
                        if (current != null && player.currentMediaItem != null) {
                            MiniPlayer(current!!, playing,
                                onOpen = { if (current!!.video) videoScreen = true else nowPlaying = true },
                                onPlay = { if (playing) player.pause() else player.play() },
                                onNext = { player.seekToNextMediaItem() })
                        }
                        NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                            listOf("Audio", "Video", "Fikirana").forEach { item ->
                                NavigationBarItem(
                                    selected = page == item, onClick = { page = item },
                                    icon = { Icon(when(item) {
                                        "Audio" -> Icons.Default.MusicNote
                                        "Video" -> Icons.Default.VideoLibrary
                                        else -> Icons.Default.Tune
                                    }, null) },
                                    label = { Text(when (item) {
                                        "Video" -> if (language == "Français") "Vidéo" else "Horonan-tsary"
                                        "Fikirana" -> if (language == "Français") "Paramètres" else "Fikirana"
                                        else -> item
                                    }) }
                                )
                            }
                        }
                    }
                }
            }
        ) { padding ->
            when {
                nowPlaying -> NowPlayingScreen(
                    current = current, player = player, playing = playing, language = language,
                    position = position, duration = duration, separationStatus = separationStatus, separationBusy = separationBusy,
                    onBack = { nowPlaying = false }, onQueue = { showQueue = true },
                    onLyrics = { showLyrics = true }, onSettings = { page = "Fikirana"; nowPlaying = false },
                    onNext = { if (player.hasNextMediaItem()) player.seekToNextMediaItem() },
                    onSeparate = {
                        val selected = current
                        if (selected != null && !separationBusy) coroutineScope.launch {
                            separationBusy = true
                            separationStatus = if (language == "Français") "Préparation de la séparation IA..." else "Manomana séparation AI..."
                            try {
                                SeparationManager.separate(context, selected.uri, language) { message ->
                                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                                        separationStatus = message
                                    }
                                }
                                separationStatus = if (language == "Français") "Terminé. Vocal et Instrumental enregistrés dans Music/YsMusicPlay." else "Vita. Voatahiry ao amin'ny Music/YsMusicPlay ny Vocal sy Instrumental."
                            } catch (error: Throwable) {
                                val detail = error.message ?: error.javaClass.simpleName
                                separationStatus = if (language == "Français") "Erreur : $detail" else "Erreur: $detail"
                            } finally { separationBusy = false }
                        }
                    },
                    onShuffle = { shuffle = !shuffle; player.shuffleModeEnabled = shuffle },
                    shuffle = shuffle, repeatMode = repeatMode,
                    onRepeat = { repeatMode = (repeatMode + 1) % 3
                        prefs.edit().putInt("repeat_mode", repeatMode).apply()
                        player.repeatMode = when (repeatMode) {
                            1 -> Player.REPEAT_MODE_ONE
                            2 -> Player.REPEAT_MODE_ALL
                            else -> Player.REPEAT_MODE_OFF
                        }
                    },
                    isFavorite = current?.let { favoriteKey(it) in favorites } == true,
                    onFavorite = { current?.let { toggleFavorite(it) } },
                    onEqualizer = {
                        runCatching {
                            if (equalizer == null && PlaybackService.audioSessionId > 0) {
                                equalizer = Equalizer(0, PlaybackService.audioSessionId)
                            }
                            if (bassBoost == null && PlaybackService.audioSessionId > 0) {
                                bassBoost = BassBoost(0, PlaybackService.audioSessionId)
                            }
                        }
                        showEqualizer = true
                    },
                    alvinEnabled = alvinEnabled, boosterEnabled = boosterEnabled,
                    onBooster = {
                        boosterEnabled = !boosterEnabled
                        runCatching {
                            if (loudnessEnhancer == null && PlaybackService.audioSessionId > 0) {
                                loudnessEnhancer = LoudnessEnhancer(PlaybackService.audioSessionId)
                            }
                            loudnessEnhancer?.apply {
                                setTargetGain(if (boosterEnabled) 500 else 0)
                                enabled = boosterEnabled
                            }
                        }
                    },
                    onAlvin = {
                        alvinEnabled = !alvinEnabled
                        player.playbackParameters = if (alvinEnabled) PlaybackParameters(1.22f, 1.28f) else PlaybackParameters(1f, 1f)
                    },
                )
                videoScreen -> VideoPlayerScreen(
                    player = player, title = current?.title ?: "Video", language = language,
                    onBack = { videoScreen = false }, position = position, duration = duration
                )
                else -> Column(Modifier.fillMaxSize().padding(padding)) {
                    Header(onRefresh = { requestLibraryAccess() }, onAbout = { showAbout = true }, language = language)
                    when (page) {
                        "Audio" -> {
                            Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                listOf("Hira", "Rakikira", "Mpanakanto", "Favoris").forEach { key ->
                                    val label = if (language == "Français") when (key) {
                                        "Hira" -> "Titres"
                                        "Rakikira" -> "Albums"
                                        "Mpanakanto" -> "Artistes"
                                        else -> "Favoris"
                                    } else key
                                    FilterChip(selected = if (key == "Favoris") showFavorites else audioSection == key,
                                        onClick = { if (key == "Favoris") showFavorites = !showFavorites else { audioSection = key; showFavorites = false } },
                                        label = { Text(label) })
                                }
                            }
                            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected = !youtubeMode, onClick = { youtubeMode = false; youtubeSearchUrl = null },
                                    label = { Text(if (language == "Français") "Recherche locale" else "Fikarohana eto an-toerana") })
                                FilterChip(selected = youtubeMode, onClick = {
                                    youtubeMode = true
                                    youtubeSearchUrl = if (search.isNotBlank()) "https://www.youtube.com/results?search_query=${Uri.encode(search)}" else null
                                }, label = { Text("YouTube") })
                            }
                            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = search, onValueChange = { search = it },
                                    modifier = Modifier.weight(1f),
                                    placeholder = { Text(if (youtubeMode) { if (language == "Français") "Rechercher sur YouTube..." else "Hitady ao amin'ny YouTube..." } else if (language == "Français") "Rechercher titres, artistes, albums..." else "Mitady hira, mpihira, rakikira...") },
                                    leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true
                                )
                                if (youtubeMode) {
                                    IconButton(onClick = {
                                        youtubeSearchUrl = if (search.isBlank()) null else "https://www.youtube.com/results?search_query=${Uri.encode(search)}"
                                    }, enabled = search.isNotBlank()) { Icon(Icons.Default.Search, "Rechercher YouTube") }
                                }
                            }
                            if (youtubeMode) {
                                if (youtubeSearchUrl != null) {
                                    InlineYoutubeSearch(url = youtubeSearchUrl!!, language = language, dataSaver = dataSaver, modifier = Modifier.fillMaxWidth().weight(1f))
                                } else {
                                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                                        Text(if (language == "Français") "Saisissez un titre puis lancez la recherche YouTube." else "Soraty ny lohateny dia atombohy ny fikarohana YouTube.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            } else {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(if (language == "Français") "Trier :" else "Filaharana:", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                                listOf("Anarana", "Daty", "Faharetana").forEach { mode ->
                                    TextButton(onClick = { sortMode = mode }) {
                                        Text(if (language == "Français") when (mode) {
                                            "Anarana" -> "Nom"
                                            "Daty" -> "Date"
                                            else -> "Durée"
                                        } else mode, color = if (sortMode == mode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                                    }
                                }
                            }
                            when (audioSection) {
                                "Rakikira" -> MediaList(sortedAudio.distinctBy { it.album }, true, onClick = { playEntry(it, sortedAudio) }, onFavorite = { toggleFavorite(it) }, favorites = favorites, onMenuAction = ::handleMediaMenu, language = language)
                                "Mpanakanto" -> MediaList(sortedAudio.distinctBy { it.artist }, false, onClick = { playEntry(it, sortedAudio) }, onFavorite = { toggleFavorite(it) }, favorites = favorites, onMenuAction = ::handleMediaMenu, language = language)
                                else -> MediaList(sortedAudio, false, onClick = { playEntry(it, sortedAudio) }, onFavorite = { toggleFavorite(it) }, favorites = favorites, onMenuAction = ::handleMediaMenu, language = language)
                            }
                            Text(scanInfo, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp, modifier = Modifier.padding(8.dp))
                            }
                        }
                        "Video" -> {
                            OutlinedTextField(value = search, onValueChange = { search = it },
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                                placeholder = { Text(if (language == "Français") "Rechercher une vidéo ou un dossier..." else "Mitady horonan-tsary na lahatahiry...") }, singleLine = true)
                            if (selectedVideoFolder == null) {
                                LazyColumn(Modifier.weight(1f)) {
                                    items(videoFolders.entries.toList(), key = { it.key }) { (folder, entries) ->
                                        ListItem(
                                            headlineContent = { Text(folder, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                            supportingContent = { Text(if (language == "Français") "${entries.size} vidéos" else "${entries.size} vidéos", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                                            leadingContent = { Icon(Icons.Default.Folder, null, tint = MaterialTheme.colorScheme.primary) },
                                            trailingContent = { Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
                                            modifier = Modifier.clickable { selectedVideoFolder = folder },
                                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                                        )
                                        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                                    }
                                }
                            } else {
                                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { selectedVideoFolder = null }) { Icon(Icons.Default.ArrowBack, if (language == "Français") "Retour" else "Miverina") }
                                    Text(selectedVideoFolder.orEmpty(), fontWeight = FontWeight.SemiBold)
                                }
                                MediaList(selectedFolderVideos, false, onClick = { playEntry(it, selectedFolderVideos) }, video = true, onMenuAction = ::handleMediaMenu, language = language)
                            }
                            Text(scanInfo, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp, modifier = Modifier.padding(8.dp))
                        }
                        else -> SettingsScreen(
                            eqEnabled = eqEnabled, bassEnabled = bassEnabled,
                            darkTheme = darkTheme, language = language, accentIndex = accentIndex,
                            backgroundImageUri = backgroundImageUri, dataSaver = dataSaver,
                            onPickBackground = { backgroundPicker.launch(arrayOf("image/*")) },
                            onClearBackground = { backgroundImageUri = null; prefs.edit().remove("background_image_uri").apply() },
                            onDataSaver = { dataSaver = it; prefs.edit().putBoolean("data_saver", it).apply() },
                            onDarkTheme = { darkTheme = it; prefs.edit().putBoolean("dark_theme", it).apply() },
                            onLanguage = { language = it; prefs.edit().putString("language", it).apply() },
                            onAccent = { accentIndex = it; prefs.edit().putInt("accent_index", it).apply() },
                            onEq = { enabled ->
                                eqEnabled = enabled
                                runCatching {
                                    if (equalizer == null && PlaybackService.audioSessionId > 0) equalizer = Equalizer(0, PlaybackService.audioSessionId)
                                    equalizer?.enabled = enabled
                                }
                            },
                            onBass = { enabled ->
                                bassEnabled = enabled
                                runCatching {
                                    if (bassBoost == null && PlaybackService.audioSessionId > 0) bassBoost = BassBoost(0, PlaybackService.audioSessionId)
                                    bassBoost?.setStrength(if (enabled) 700.toShort() else 0.toShort())
                                    bassBoost?.enabled = enabled
                                }
                            },
                            onAbout = { showAbout = true }
                        )
                    }
                }
            }
            }
        }
    }

    infoEntry?.let { entry ->
        AlertDialog(
            onDismissRequest = { infoEntry = null },
            title = { Text(if (language == "Français") "Information" else "Mombamomba") },
            text = { Text("${entry.title}\n${entry.artist}\n${entry.album}\n${formatTime(entry.duration)}\n${entry.uri}") },
            confirmButton = { TextButton(onClick = { infoEntry = null }) { Text("OK") } }
        )
    }

    if (showEqualizer) AlertDialog(
        onDismissRequest = { showEqualizer = false },
        title = { Text(if (language == "Français") "Égaliseur • Bass Booster" else "Equalizer • Bass Booster", color = MaterialTheme.colorScheme.onSurface) },
        text = {
            Column(Modifier.heightIn(max = 540.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (language == "Français") "Préréglages" else "Safidy feo", color = MaterialTheme.colorScheme.onSurface)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = boosterEnabled, onClick = {
                        boosterEnabled = !boosterEnabled
                        runCatching {
                            if (loudnessEnhancer == null && PlaybackService.audioSessionId > 0) loudnessEnhancer = LoudnessEnhancer(PlaybackService.audioSessionId)
                            loudnessEnhancer?.apply { setTargetGain(if (boosterEnabled) 500 else 0); enabled = boosterEnabled }
                        }
                    }, label = { Text(if (boosterEnabled) { if (language == "Français") "Volume Booster ON" else "Fanamafisana feo ON" } else { if (language == "Français") "Volume Booster" else "Fanamafisana feo" }) })
                }
                listOf("Normal", "Jazz", "Rock", "Bass", "Treble").forEach { preset ->
                    FilterChip(selected = selectedPreset == preset, onClick = {
                        selectedPreset = preset
                        runCatching {
                            if (equalizer == null && PlaybackService.audioSessionId > 0) equalizer = Equalizer(0, PlaybackService.audioSessionId)
                            equalizer?.let { eq ->
                                eq.enabled = preset != "Normal"
                                if (eq.numberOfBands > 0) {
                                    val range = eq.bandLevelRange
                                    for (band in 0 until eq.numberOfBands) {
                                        val value = when (preset) {
                                            "Bass" -> if (band < eq.numberOfBands / 2) range[1] else 0
                                            "Treble" -> if (band >= eq.numberOfBands / 2) range[1] else 0
                                            "Rock" -> if (band == 0 || band == eq.numberOfBands - 1) range[1] else 0
                                            "Jazz" -> if (band == 1 || band == eq.numberOfBands - 2) range[1] / 2 else 0
                                            else -> 0
                                        }
                                        eq.setBandLevel(band.toShort(), value.toShort())
                                    }
                                }
                            }
                            if (bassBoost == null && PlaybackService.audioSessionId > 0) bassBoost = BassBoost(0, PlaybackService.audioSessionId)
                            bassBoost?.apply { setStrength(if (preset == "Bass") 850.toShort() else 0.toShort()); enabled = preset == "Bass" }
                        }
                    }, label = { Text(preset) })
                }
                Text(if (language == "Français") "Les effets audio dépendent du matériel du téléphone." else "Miankina amin'ny fanohanan'ny finday ny effet audio.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = { showEqualizer = false }) { Text(if (language == "Français") "Terminer" else "Vita") } }
    )
    if (showQueue) AlertDialog(
        onDismissRequest = { showQueue = false },
        title = { Text(if (language == "Français") "File d’attente" else "Filaharana", color = MaterialTheme.colorScheme.onSurface) },
        text = {
            Column(Modifier.heightIn(max = 420.dp)) {
                val list = (0 until player.mediaItemCount).mapNotNull { i ->
                    player.getMediaItemAt(i).mediaMetadata.title?.toString()?.let { it to i }
                }
                LazyColumn {
                    items(list) { (title, index) ->
                        ListItem(headlineContent = { Text(title, color = MaterialTheme.colorScheme.onSurface, fontWeight = if (index == player.currentMediaItemIndex) FontWeight.Bold else FontWeight.Normal) },
                            supportingContent = { if (index == player.currentMediaItemIndex) Text(if (language == "Français") "En cours" else "Mandeha izao", color = MaterialTheme.colorScheme.primary) },
                            modifier = Modifier.clickable { player.seekTo(index, 0L); player.play(); showQueue = false },
                            colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.surface))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showQueue = false }) { Text(if (language == "Français") "Fermer" else "Hidio") } }
    )
    if (showLyrics) AlertDialog(
        onDismissRequest = { showLyrics = false },
        title = { Text(if (language == "Français") "Paroles" else "Tononkira", color = MaterialTheme.colorScheme.onSurface) },
        text = {
            OutlinedTextField(value = lyricsText, onValueChange = { lyricsText = it },
                modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp),
                textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface, lineHeight = 26.sp),
                placeholder = { Text(if (language == "Français") "Saisir les paroles ici..." else "Ampidiro eto ny tononkira...") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = MaterialTheme.colorScheme.onSurface,
                    unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                ))
        },
        confirmButton = { TextButton(onClick = { showLyrics = false }) { Text(if (language == "Français") "Terminer" else "Vita") } }
    )
    if (showAbout) AlertDialog(
        onDismissRequest = { showAbout = false },
        title = { Text("Ys Music Play") },
        text = { Column {
            Text(if (language == "Français") "Version 6.0.0" else "Kinova 6.0.0")
            Text(if (language == "Français") "Créateur : Haritiana" else "Mpamorona: Haritiana")
            Text(if (language == "Français") "Studio : Ys Production" else "Studio: Ys Production")
            Text("WhatsApp: +261 33 95 146 95")
        } },
        confirmButton = { TextButton(onClick = { showAbout = false }) { Text(if (language == "Français") "Fermer" else "Hidio") } }
    )
}

@Composable
private fun Header(onRefresh: () -> Unit, onAbout: () -> Unit, language: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.GraphicEq, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("YS MUSIC PLAY", fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Text("Ys Production", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
        }
        IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, if (language == "Français") "Actualiser" else "Havaozy") }
        IconButton(onClick = onAbout) { Icon(Icons.Default.Info, if (language == "Français") "À propos" else "Mombamomba") }
    }
}

@Composable
private fun MediaList(entries: List<MediaEntry>, showAlbum: Boolean, onClick: (MediaEntry) -> Unit, video: Boolean = false,
                      onFavorite: ((MediaEntry) -> Unit)? = null, favorites: Set<String> = emptySet(),
                      onMenuAction: (MediaEntry, String) -> Unit = { _, _ -> }, language: String = "Français") {
    var menuEntry by remember { mutableStateOf<MediaEntry?>(null) }
    LazyColumn(Modifier.fillMaxSize()) {
        items(entries, key = { "${it.video}-${it.id}" }) { entry ->
            ListItem(
                headlineContent = { Text(if (showAlbum) entry.album else entry.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                supportingContent = {
                    Text(if (video) "${entry.folder} • ${formatTime(entry.duration)}"
                    else "${entry.artist} • ${entry.album} • ${formatTime(entry.duration)}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                },
                leadingContent = {
                    if (video) AsyncImage(model = entry.uri, contentDescription = if (language == "Français") "Miniature vidéo" else "Sary kely amin'ny vidéo", contentScale = ContentScale.Crop,
                        modifier = Modifier.size(64.dp, 48.dp).background(MaterialTheme.colorScheme.surface, RoundedCornerShape(6.dp)))
                    else Icon(Icons.Default.MusicNote, null, tint = MaterialTheme.colorScheme.primary)
                },
                trailingContent = {
                    Box {
                        IconButton(onClick = { menuEntry = entry }) { Icon(Icons.Default.MoreVert, if (language == "Français") "Options" else "Safidy", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                        DropdownMenu(expanded = menuEntry?.id == entry.id && menuEntry?.video == entry.video, onDismissRequest = { menuEntry = null }) {
                            val options = buildList {
                                add("Lire tout")
                                add("Ajouter à la file d’attente")
                                add("Ajouter juste après")
                                add("Information")
                                if (!video) { add("Accéder à l’album"); add("Accéder à l’artiste") }
                                add("Ajouter aux favoris")
                                add("Partager")
                                add("Supprimer")
                                add("Parcourir le parent")
                            }
                            options.forEach { option ->
                                DropdownMenuItem(text = { Text(if (language == "Français") option else when (option) {
                                    "Lire tout" -> "Alefaso"
                                    "Ajouter à la file d’attente" -> "Ampidiro anaty filaharana"
                                    "Ajouter juste après" -> "Alefaso manaraka"
                                    "Information" -> "Mombamomba"
                                    "Accéder à l’album" -> "Hijery ny rakikira"
                                    "Accéder à l’artiste" -> "Hijery ny mpanakanto"
                                    "Ajouter aux favoris" -> "Ampidiro amin’ny tiana"
                                    "Partager" -> "Zarao"
                                    "Supprimer" -> "Fafao"
                                    "Parcourir le parent" -> "Hijery ny lahatahiry"
                                    else -> option
                                }) }, onClick = {
                                    menuEntry = null
                                    if (option == "Ajouter aux favoris" && onFavorite != null) onFavorite(entry)
                                    else onMenuAction(entry, option)
                                })
                            }
                        }
                    }
                },
                modifier = Modifier.clickable { onClick(entry) },
                colors = ListItemDefaults.colors(containerColor = Color.Transparent)
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
        }
    }
}

@Composable
private fun MiniPlayer(entry: MediaEntry, playing: Boolean, onOpen: () -> Unit, onPlay: () -> Unit, onNext: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).clickable { onOpen() }.padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(if (entry.video) Icons.Default.VideoFile else Icons.Default.MusicNote, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
        Column(Modifier.weight(1f).padding(start = 10.dp)) {
            Text(entry.title, maxLines = 1, fontWeight = FontWeight.SemiBold)
            Text(entry.artist, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
        }
        IconButton(onClick = onPlay) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null) }
        IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null) }
    }
}

@Composable
private fun NowPlayingScreen(
    current: MediaEntry?, player: MediaController, playing: Boolean, language: String, position: Long, duration: Long,
    separationStatus: String, separationBusy: Boolean,
    onBack: () -> Unit, onQueue: () -> Unit, onLyrics: () -> Unit, onSettings: () -> Unit,
    onNext: () -> Unit, onSeparate: () -> Unit,
    onShuffle: () -> Unit, shuffle: Boolean, repeatMode: Int, onRepeat: () -> Unit,
    isFavorite: Boolean, onFavorite: () -> Unit, onEqualizer: () -> Unit,
    alvinEnabled: Boolean, boosterEnabled: Boolean, onBooster: () -> Unit, onAlvin: () -> Unit
) {
    var showSeparationChoices by remember { mutableStateOf(false) }
    var speed by remember { mutableFloatStateOf(1f) }
    var pitch by remember { mutableFloatStateOf(1f) }
    val fr = language == "Français"
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background.copy(alpha = 0.48f))
            .padding(horizontal = 14.dp, vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.KeyboardArrowDown, if (fr) "Retour" else "Miverina") }
            Text(if (fr) "Lecture en cours" else "Mandeha izao", Modifier.weight(1f), fontWeight = FontWeight.Bold)
            IconButton(onClick = onQueue) { Icon(Icons.Default.QueueMusic, if (fr) "File d’attente" else "Filaharana") }
            IconButton(onClick = onSettings) { Icon(Icons.Default.Tune, if (fr) "Paramètres" else "Fikirana") }
        }
        Box(
            Modifier.fillMaxWidth().weight(1f, fill = false).heightIn(min = 145.dp, max = 235.dp)
                .clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface),
            contentAlignment = Alignment.Center
        ) {
            if (current?.artwork != null) {
                AsyncImage(model = current.artwork, contentDescription = if (fr) "Pochette de l’album" else "Fonon'ny rakikira",
                    contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            } else {
                Icon(Icons.Default.Album, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(96.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(current?.title ?: if (fr) "Titre" else "Hira", fontSize = 21.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(current?.artist ?: "", color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, fontSize = 13.sp)
        Slider(value = position.toFloat().coerceIn(0f, duration.coerceAtLeast(1).toFloat()),
            onValueChange = { player.seekTo(it.toLong()) }, valueRange = 0f..duration.coerceAtLeast(1).toFloat())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(position), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
            Text(formatTime(duration), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onShuffle) { Icon(Icons.Default.Shuffle, if (fr) "Aléatoire" else "Kisendrasendra", tint = if (shuffle) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant) }
            IconButton(onClick = { player.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, if (fr) "Précédent" else "Teo aloha") }
            FilledIconButton(onClick = { if (playing) player.pause() else player.play() }, modifier = Modifier.size(58.dp)) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (fr) "Lecture / Pause" else "Alefa / Atsaharo")
            }
            IconButton(onClick = onNext, enabled = player.hasNextMediaItem()) { Icon(Icons.Default.SkipNext, if (fr) "Suivant" else "Manaraka") }
            IconButton(onClick = onRepeat) {
                Box {
                    Icon(Icons.Default.Repeat, if (fr) "Répétition ${listOf("OFF", "ONE", "ALL")[repeatMode]}" else "Famerenana ${listOf("TSIA", "IRAY", "REHETRA")[repeatMode]}", tint = if (repeatMode == 0) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.primary)
                    if (repeatMode == 1) Text("1", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.align(Alignment.TopEnd))
                }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(if (fr) "Vitesse" else "Hafainganana", fontSize = 12.sp, modifier = Modifier.width(76.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Slider(value = speed, onValueChange = { speed = it; player.playbackParameters = PlaybackParameters(speed, pitch) },
                valueRange = 0.5f..2f, modifier = Modifier.weight(1f))
            Text("${"%.2f".format(java.util.Locale.US, speed)}x", fontSize = 12.sp, modifier = Modifier.width(48.dp), textAlign = TextAlign.End)
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Pitch", fontSize = 12.sp, modifier = Modifier.width(76.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Slider(value = pitch, onValueChange = { pitch = it; player.playbackParameters = PlaybackParameters(speed, pitch) },
                valueRange = 0.5f..5f, modifier = Modifier.weight(1f))
            Text("${"%.1f".format(java.util.Locale.US, pitch)}x", fontSize = 12.sp, modifier = Modifier.width(48.dp), textAlign = TextAlign.End)
            TextButton(onClick = { pitch = 1f; player.playbackParameters = PlaybackParameters(speed, pitch) }) { Text(if (fr) "Reset" else "Avereno") }
        }
        if (separationStatus.isNotBlank()) {
            Text(separationStatus, color = if (separationStatus.startsWith("Erreur")) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp, maxLines = 2)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onFavorite, modifier = Modifier.weight(1f)) { Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(3.dp)); Text(if (fr) "Favoris" else "Tiana", maxLines = 1) }
            OutlinedButton(onClick = onLyrics, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Lyrics, null); Spacer(Modifier.width(3.dp)); Text(if (fr) "Paroles" else "Tononkira", maxLines = 1) }
            OutlinedButton(onClick = { showSeparationChoices = true }, enabled = !separationBusy, modifier = Modifier.weight(1.35f)) { Icon(Icons.Default.GraphicEq, null); Spacer(Modifier.width(3.dp)); Text(if (separationBusy) "AI…" else if (fr) "Séparation" else "Fanasarahana", maxLines = 1) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(
                onClick = onEqualizer,
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 5.dp, vertical = 8.dp)
            ) {
                Icon(Icons.Default.Equalizer, null)
                Spacer(Modifier.width(3.dp))
                Text("EQ", maxLines = 1, softWrap = false)
            }
            OutlinedButton(
                onClick = onAlvin,
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 5.dp, vertical = 8.dp)
            ) {
                Text(if (alvinEnabled) "Alvin ON" else "Alvin", maxLines = 1, softWrap = false, fontSize = 12.sp)
            }
            OutlinedButton(
                onClick = onBooster,
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 5.dp, vertical = 8.dp)
            ) {
                Text(
                    if (fr) { if (boosterEnabled) "Boost ON" else "Boost" } else { if (boosterEnabled) "Fanamafisana ON" else "Fanamafisana" },
                    maxLines = 1, softWrap = false, fontSize = 12.sp
                )
            }
        }
    }
    if (showSeparationChoices) AlertDialog(
        onDismissRequest = { showSeparationChoices = false },
        title = { Text(if (fr) "Vocal / Instrumental" else "Feo / Instrumental") },
        text = { Text(if (fr)
            "Le modèle IA est téléchargé une seule fois (environ 55 MB). Ensuite, la séparation fonctionne hors ligne. Le traitement utilise un nombre de threads limité pour préserver la mémoire du téléphone."
            else "Indray mandeha ihany no alaina ny modely AI (eo amin'ny 55 MB). Aorian'izay dia afaka mandeha offline ny séparation. Voafetra ny isan'ny threads mba hiarovana ny RAM.") },
        confirmButton = {
            Column(horizontalAlignment = Alignment.End) {
                TextButton(enabled = !separationBusy, onClick = { showSeparationChoices = false; onSeparate() }) { Text(if (separationBusy) { if (fr) "Traitement..." else "Eo am-panatanterahana..." } else if (fr) "Séparer maintenant" else "Saraho izao") }
                TextButton(onClick = { showSeparationChoices = false }) { Text(if (fr) "Fermer" else "Hidio") }
            }
        }
    )
}

@Composable
private fun InlineYoutubeSearch(url: String, language: String, dataSaver: Boolean, modifier: Modifier = Modifier) {
    var loadError by remember(url) { mutableStateOf<String?>(null) }
    var webView by remember(url) { mutableStateOf<android.webkit.WebView?>(null) }
    Column(modifier) {
        if (loadError != null) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(loadError!!, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                TextButton(onClick = { loadError = null; webView?.reload() }) { Text(if (language == "Français") "Réessayer" else "Andramo indray") }
            }
        }
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx -> android.webkit.WebView(ctx).apply {
                webView = this
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.loadsImagesAutomatically = !dataSaver
                settings.cacheMode = if (dataSaver) android.webkit.WebSettings.LOAD_CACHE_ELSE_NETWORK else android.webkit.WebSettings.LOAD_DEFAULT
                settings.mediaPlaybackRequiresUserGesture = true
                webViewClient = object : android.webkit.WebViewClient() {
                    override fun onReceivedError(view: android.webkit.WebView?, request: android.webkit.WebResourceRequest?, error: android.webkit.WebResourceError?) {
                        if (request?.isForMainFrame == true) loadError = if (language == "Français") "Erreur de chargement YouTube. Vérifiez Internet puis réessayez." else "Nisy olana tamin'ny famoahana YouTube. Jereo ny fifandraisana dia andramo indray."
                    }
                    override fun onPageStarted(view: android.webkit.WebView?, pageUrl: String?, favicon: android.graphics.Bitmap?) { loadError = null }
                }
                loadUrl(url)
            } },
            update = { view ->
                view.settings.loadsImagesAutomatically = !dataSaver
                view.settings.cacheMode = if (dataSaver) android.webkit.WebSettings.LOAD_CACHE_ELSE_NETWORK else android.webkit.WebSettings.LOAD_DEFAULT
                if (view.url != url) { loadError = null; view.loadUrl(url) }
            }
        )
    }
}

@Composable
private fun VideoPlayerScreen(
    player: MediaController, title: String, language: String, onBack: () -> Unit,
    position: Long, duration: Long
) {
    var rotation by remember { mutableIntStateOf(0) }
    var autoRotate by remember { mutableStateOf(false) }
    var locked by remember { mutableStateOf(false) }
    var landscape by remember { mutableStateOf(false) }
    var gestureLabel by remember { mutableStateOf("") }
    var gestureValue by remember { mutableFloatStateOf(0f) }
    var videoPitch by remember { mutableFloatStateOf(1f) }
    var videoSpeed by remember { mutableFloatStateOf(1f) }
    var showVideoOptions by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val activity = context as? Activity
    val audioManager = remember(context) { context.getSystemService(android.content.Context.AUDIO_SERVICE) as AudioManager }
    var brightness by remember {
        mutableFloatStateOf(
            (activity?.window?.attributes?.screenBrightness ?: 0.5f).let {
                if (it in 0.01f..1f) it else 0.5f
            }
        )
    }
    var volume by remember {
        mutableFloatStateOf(
            audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() /
                audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        )
    }
    DisposableEffect(Unit) {
        onDispose {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            player.playbackParameters = PlaybackParameters(1f, 1f)
        }
    }
    LaunchedEffect(Unit) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        if (!locked) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, if (language == "Français") "Retour" else "Miverina", tint = Color.White) }
                Text(title, color = Color.White, maxLines = 1, modifier = Modifier.weight(1f))
                IconButton(onClick = { rotation = (rotation + 90) % 360 }) {
                    Icon(Icons.Default.ScreenRotation, if (language == "Français") "Rotation" else "Ahodina", tint = Color.White)
                }
                IconButton(onClick = {
                    landscape = !landscape
                    activity?.requestedOrientation = if (landscape)
                        ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                }) { Icon(Icons.Default.StayCurrentLandscape, if (language == "Français") "Paysage" else "Marindrano", tint = Color.White) }
                IconButton(onClick = {
                    autoRotate = !autoRotate
                    activity?.requestedOrientation = if (autoRotate)
                        ActivityInfo.SCREEN_ORIENTATION_SENSOR
                    else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                }) {
                    Icon(Icons.Default.ScreenLockRotation, if (language == "Français") "Rotation automatique" else "Rotation mandeha ho azy",
                        tint = if (autoRotate) MaterialTheme.colorScheme.primary else Color.White)
                }
                IconButton(onClick = { locked = true }) {
                    Icon(Icons.Default.LockOpen, if (language == "Français") "Verrouiller" else "Hidio", tint = Color.White)
                }
                Box {
                    IconButton(onClick = { showVideoOptions = true }) {
                        Icon(Icons.Default.MoreVert, if (language == "Français") "Plus d’options" else "Safidy fanampiny", tint = Color.White)
                    }
                    DropdownMenu(expanded = showVideoOptions, onDismissRequest = { showVideoOptions = false }) {
                        DropdownMenuItem(
                            text = { Text(if (language == "Français") "Réinitialiser Pitch" else "Avereno ny Pitch") },
                            onClick = { videoPitch = 1f; videoSpeed = 1f; player.playbackParameters = PlaybackParameters(1f, 1f); showVideoOptions = false }
                        )
                        DropdownMenuItem(
                            text = { Text(if (language == "Français") "Rotation +90°" else "Ahodina +90°") },
                            onClick = { rotation = (rotation + 90) % 360; showVideoOptions = false }
                        )
                        DropdownMenuItem(
                            text = { Text(if (language == "Français") "Verrouiller l’écran" else "Hidio ny écran") },
                            onClick = { locked = true; showVideoOptions = false }
                        )
                    }
                }
            }
        }
        Box(
            Modifier.fillMaxWidth().weight(1f)
                .pointerInput(locked) {
                    detectVerticalDragGestures { change, dragAmount ->
                        if (!locked) {
                            change.consume()
                            val leftSide = change.position.x < size.width / 2f
                            if (leftSide) {
                                brightness = (brightness - dragAmount / size.height).coerceIn(0.05f, 1f)
                                activity?.let { host ->
                                    val params = host.window.attributes
                                    params.screenBrightness = brightness
                                    host.window.attributes = params
                                }
                                gestureLabel = if (language == "Français") "Luminosité" else "Famirapiratana"
                                gestureValue = brightness
                            } else {
                                val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                                val next = (currentVolume - (dragAmount / size.height * maxVolume * 2f)).toInt()
                                    .coerceIn(0, maxVolume)
                                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, next, 0)
                                volume = next.toFloat() / maxVolume
                                gestureLabel = if (language == "Français") "Volume" else "Feo"
                                gestureValue = volume
                            }
                        }
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                factory = { ctx -> PlayerView(ctx).apply {
                    this.player = player
                    useController = true
                    controllerAutoShow = true
                    setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                    keepScreenOn = true
                } },
                update = {
                    it.player = player
                    it.rotation = rotation.toFloat()
                    it.useController = !locked
                },
                modifier = Modifier.fillMaxSize()
            )
            if (gestureLabel.isNotEmpty() && !locked) {
                LaunchedEffect(gestureLabel, gestureValue) {
                    delay(650)
                    gestureLabel = ""
                }
                Column(
                    Modifier.align(Alignment.Center).clip(RoundedCornerShape(12.dp))
                        .background(Color(0xAA202020)).padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(gestureLabel, color = Color.White)
                    LinearProgressIndicator(progress = { gestureValue }, modifier = Modifier.width(120.dp))
                    Text("${(gestureValue * 100).toInt()}%", color = Color.White)
                }
            }
            if (locked) {
                FilledTonalButton(
                    onClick = { locked = false },
                    modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)
                ) { Icon(Icons.Default.LockOpen, null); Spacer(Modifier.width(6.dp)); Text(if (language == "Français") "Déverrouiller" else "Mamaha hidy") }
            }
        }
        if (!locked) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(position), color = Color.White)
                Text(formatTime(duration), color = Color.White)
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Pitch", color = Color.White, fontSize = 12.sp, modifier = Modifier.width(48.dp))
                Slider(value = videoPitch, onValueChange = { videoPitch = it; player.playbackParameters = PlaybackParameters(videoSpeed, videoPitch) }, valueRange = 0.5f..5f, modifier = Modifier.weight(1f))
                Text("${"%.1f".format(Locale.US, videoPitch)}x", color = Color.White, fontSize = 11.sp)
                TextButton(onClick = { videoPitch = 1f; videoSpeed = 1f; player.playbackParameters = PlaybackParameters(1f, 1f) }) { Text(if (language == "Français") "Reset" else "Avereno") }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    eqEnabled: Boolean, bassEnabled: Boolean,
    darkTheme: Boolean, language: String, accentIndex: Int, backgroundImageUri: String?, dataSaver: Boolean,
    onDarkTheme: (Boolean) -> Unit, onLanguage: (String) -> Unit, onAccent: (Int) -> Unit,
    onPickBackground: () -> Unit, onClearBackground: () -> Unit, onDataSaver: (Boolean) -> Unit,
    onEq: (Boolean) -> Unit, onBass: (Boolean) -> Unit, onAbout: () -> Unit
) {
    val accents = listOf(Color(0xFFFF8A00), Color(0xFF2196F3), Color(0xFF4CAF50), Color(0xFFE91E63), Color(0xFF9C27B0))
    val foreground = if (darkTheme) Color.White else Color(0xFF17181D)
    CompositionLocalProvider(LocalContentColor provides foreground) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text(if (language == "Français") "PARAMÈTRES" else "FIKIRANA", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.height(14.dp))
        Text(if (language == "Français") "PERSONNALISATION" else "FANAMBOARANA", fontWeight = FontWeight.Bold)
        SettingSwitch(if (language == "Français") "Thème sombre" else "Thème maizina", darkTheme, onDarkTheme)
        Text(if (language == "Français") "Couleur principale" else "Loko fototra", fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(vertical = 8.dp)) {
            accents.forEachIndexed { index, color ->
                Box(Modifier.size(34.dp).clip(CircleShape).background(color).clickable { onAccent(index) }, contentAlignment = Alignment.Center) {
                    if (accentIndex == index) Icon(Icons.Default.Check, null, tint = Color.White)
                }
            }
        }
        Text(if (language == "Français") "Langue" else "Fiteny", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = language == "Français", onClick = { onLanguage("Français") }, label = { Text("Français") })
            FilterChip(selected = language == "Malagasy", onClick = { onLanguage("Malagasy") }, label = { Text("Malagasy") })
        }
        Spacer(Modifier.height(14.dp))
        Text(if (language == "Français") "AUDIO" else "FEON-KIRA", fontWeight = FontWeight.Bold)
        SettingSwitch(if (language == "Français") "Égaliseur" else "Equalizer", eqEnabled, onEq)
        SettingSwitch(if (language == "Français") "Bass Booster" else "Bass Booster", bassEnabled, onBass)
        Spacer(Modifier.height(16.dp))
        Text(if (language == "Français") "ARRIÈRE-PLAN PERSONNALISÉ" else "SARY AMBADIANA", fontWeight = FontWeight.Bold)
        Text(if (language == "Français") "Choisir une image depuis la galerie" else "Misafidiana sary avy ao amin'ny Galerie", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onPickBackground) { Icon(Icons.Default.Image, null); Spacer(Modifier.width(6.dp)); Text(if (language == "Français") "Choisir une image" else "Hisafidy sary") }
            if (backgroundImageUri != null) OutlinedButton(onClick = onClearBackground) { Text(if (language == "Français") "Retirer" else "Esory") }
        }
        SettingSwitch(if (language == "Français") "Économiseur de données (pages Web)" else "Fitsitsiana data (pejy Web)", dataSaver, onDataSaver)
        Spacer(Modifier.height(18.dp))
        TextButton(onClick = onAbout) { Icon(Icons.Default.Info, null); Spacer(Modifier.width(6.dp)); Text(if (language == "Français") "À propos" else "Mombamomba ny rindranasa") }
        Text(if (language == "Français") "L’égaliseur et le Bass Booster dépendent du matériel audio du téléphone." else "Miankina amin'ny fanohanan'ny finday ny Equalizer sy Bass Booster.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
    }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked, onCheckedChange = onChange)
    }
}

private fun formatTime(ms: Long): String {
    if (ms <= 0) return "0:00"
    val sec = ms / 1000
    return "%d:%02d".format(sec / 60, sec % 60)
}
