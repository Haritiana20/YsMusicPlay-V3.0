package com.ysmusicplay

import android.content.Context
import android.media.AudioManager
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null

    companion object {
        @Volatile
        var audioSessionId: Int = 0
            private set
    }

    override fun onCreate() {
        super.onCreate()
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val generatedSessionId = audioManager.generateAudioSessionId()
        val player = ExoPlayer.Builder(this).build()

        if (generatedSessionId > 0) {
            player.setAudioSessionId(generatedSessionId)
            audioSessionId = generatedSessionId
        } else {
            audioSessionId = 0
        }

        mediaSession = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onDestroy() {
        mediaSession?.let {
            it.player.release()
            it.release()
        }
        mediaSession = null
        audioSessionId = 0
        super.onDestroy()
    }
}
